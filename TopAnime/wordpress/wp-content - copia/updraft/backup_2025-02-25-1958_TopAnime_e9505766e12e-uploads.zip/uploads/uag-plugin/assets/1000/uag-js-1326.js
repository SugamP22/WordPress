document.addEventListener("DOMContentLoaded", function(){ window.addEventListener( 'load', function() {
	UAGBButtonChild.init( '.uagb-block-6f0cd200' );
});
window.addEventListener( 'load', function() {
	UAGBButtonChild.init( '.uagb-block-da6a4fc4' );
});
window.addEventListener( 'load', function() {
	UAGBButtonChild.init( '.uagb-block-26a2717b' );
});
window.addEventListener( 'load', function() {
	UAGBButtonChild.init( '.uagb-block-a09791e7' );
});
window.addEventListener( 'load', function() {
	UAGBButtonChild.init( '.uagb-block-96399023' );
});
window.addEventListener( 'load', function() {
	UAGBButtonChild.init( '.uagb-block-fc45789f' );
});
window.addEventListener( 'load', function() {
	UAGBButtonChild.init( '.uagb-block-cab9d2e8' );
});
window.addEventListener( 'load', function() {
	UAGBButtonChild.init( '.uagb-block-f6912abe' );
});
window.addEventListener( 'load', function() {
	UAGBButtonChild.init( '.uagb-block-61abdc0a' );
});
window.addEventListener( 'load', function() {
	UAGBButtonChild.init( '.uagb-block-8ab817e9' );
});
 });