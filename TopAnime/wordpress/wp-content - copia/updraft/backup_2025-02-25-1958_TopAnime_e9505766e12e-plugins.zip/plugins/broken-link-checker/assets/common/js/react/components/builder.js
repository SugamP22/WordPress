import React from 'react';

const { __ } = wp.i18n;

export function Builder( props ) {


    return(
        <div className="sui-box-builder">

            <div className="sui-box-builder-header">

            </div>

            <div className="sui-box-builder-body">


            </div>

        </div>
    )

}
